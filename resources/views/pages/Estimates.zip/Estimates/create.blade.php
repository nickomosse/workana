@extends('adminlte::page')

@section('title', "Orçamento")

@section('content_header')
    <h1>Novo Orçamento</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-body">
            @if ($errors->any())
                <div class="alert alert-danger">
                    @foreach ($errors->all() as $error)
                        <p>{{$error}}</p>
                    @endforeach
                </div>
            @endif

            <form action="{{route('estimates.store')}}" class="form" method="POST">
                @csrf
                <div class="row">
                    <div class="form-group col-md-4">
                        <label>Nome:</label>
                        <input type="text" name="name" class="form-control" placeholder="Artur Santos">
                    </div>
                    <div class="form-group col-md-4">
                        <label>Nascimento:</label>
                        <input type="date" name="birthday" class="form-control">
                    </div>
                    <div class="form-group col-md-4">
                        <label for="gender">Gênero:</label>
                        <select class="custom-select rounded-0" id="gender" name="gender">
                            <option value=1>Masculino</option>
                            <option value=0>Feminino</option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="form-group col-md-3">
                        <label>Data da festa:</label>
                        <input type="date" name="date" class="form-control" placeholder="06/04/2025">
                    </div>

                    <div class="form-group col-md-3">
                        <label for="package">Pacote da festa:</label>
                        <select class="custom-select rounded-0" id="package" name="package">
                            @foreach ($packages as $package)
                                <option value="{{$package->id}}">{{$package->name}}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group col-md-3">
                        <label for="referral">Como conheceu o espaço:</label>
                        <select class="custom-select rounded-0" id="referral" name="referral">
                            @foreach ($referrals as $referral)
                                <option value="{{$referral->id}}">{{$referral->name}}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group col-md-3">
                        <label for="partyTime">Hora da festa:</label>
                        <select class="custom-select rounded-0" id="partyTime" name="partyTime_id">
                            @foreach ($partyTimes as $partyTime)
                                <option value="{{$partyTime->id}}">{{date('H:i', strtotime($partyTime->start))}} às {{date('H:i', strtotime($partyTime->end))}}</option>
                            @endforeach
                        </select>
                    </div>

                </div>
                <hr>
                <div class="row">
                    <div class="form-group col-md-4">
                        <label>Nome do responsável 1:</label>
                        <input type="text" name="frespname" class="form-control" placeholder="Tereza Cruz">
                    </div>
                    <div class="form-group col-md-4">
                        <label>Email do responsável 1:</label>
                        <input type="email" name="frespemail" class="form-control" placeholder="tere@hotmail.com">
                    </div>
                    <div class="form-group col-md-4">
                        <label>Celular do responsável 1:</label>
                        <input type="text" name="frespcel" class="form-control" placeholder="284453448">
                    </div>
                </div>

                <div class="row">
                    <div class="form-group col-md-4">
                        <label>Nome do responsável 2:</label>
                        <input type="text" name="srespname" class="form-control" placeholder="Marcos Cruz">
                    </div>
                    <div class="form-group col-md-4">
                        <label>Celular do responsável 2:</label>
                        <input type="text" name="srespcel" class="form-control" placeholder="21985641245">
                    </div>
                </div>
                <hr>

                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label>Observação:</label>
                            <textarea class="form-control" name="comment" rows="5"></textarea>

                        </div>
                    </div>
                    <div class="col-sm-2"></div>
                    <div class="col-sm-4 mt-4">
                        <div class="form-group">
                            <label for="observations">Observações rápidas:</label>
                            @foreach ($observations as $observation)
                                <div class="custom-control custom-checkbox">
                                    <input class="custom-control-input custom-control-input-danger" type="checkbox" id="{{$observation->id}}" name="observations[]" value="{{$observation->id}}">
                                    <label for="{{$observation->id}}" class="custom-control-label">{{$observation->name}}</label>
                                </div>
                            @endforeach
                        </div>
                    </div>

                </div>


                <div class="form-group">
                    <button type="submit" class="btn btn-success">Salvar</button>
                </div>
            </form>

        </div>
    </div>
@endsection
